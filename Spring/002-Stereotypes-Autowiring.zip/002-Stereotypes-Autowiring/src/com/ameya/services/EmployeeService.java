package com.ameya.services;

import com.ameya.daos.EmployeeDAO;

public interface EmployeeService {
	
	public void create();
}
