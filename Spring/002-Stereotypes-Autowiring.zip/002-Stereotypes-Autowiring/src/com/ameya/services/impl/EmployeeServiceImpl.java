package com.ameya.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ameya.daos.EmployeeDAO;
import com.ameya.services.EmployeeService;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDao;
	/*@Override
	public void setEmployeeDao(EmployeeDAO employeeDao) {
		this.employeeDao=employeeDao;
		System.out.println("+++ DAO Injected +++");
	}
*/
	@Override
	public void create() {
		System.out.println("+++ Create of service +++");
		employeeDao.create();
	}

}
