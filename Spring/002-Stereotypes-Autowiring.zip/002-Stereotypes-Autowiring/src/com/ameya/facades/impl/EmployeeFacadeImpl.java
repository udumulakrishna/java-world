package com.ameya.facades.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ameya.facades.EmployeeFacade;
import com.ameya.services.EmployeeService;

@Component("employeeFacade")
public class EmployeeFacadeImpl implements EmployeeFacade {
	
	@Autowired
	private EmployeeService employeeService;
	/*@Override
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService=employeeService;
		System.out.println("+++ Service Injected +++");
	}*/
	@Override
	public void create() {
		System.out.println("+++ Create of facade +++");
		employeeService.create();
	}
}
