package com.ameya.facades;

import com.ameya.services.EmployeeService;

public interface EmployeeFacade {
	
	public void create();
}
