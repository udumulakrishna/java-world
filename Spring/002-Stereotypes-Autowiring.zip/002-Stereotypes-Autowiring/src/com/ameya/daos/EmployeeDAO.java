package com.ameya.daos;

public interface EmployeeDAO {
	public void create();
}
