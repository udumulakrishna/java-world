package com.ameya.daos.impl;

import org.springframework.stereotype.Repository;

import com.ameya.daos.EmployeeDAO;

@Repository("employeeDao")
public class EmployeeDAOImpl implements EmployeeDAO {
	/*
	 * Some additional dependencies like transaction managers
	 * jdbc related templates etc might be injected here
	 */
	@Override
	public void create() {
		System.out.println("+++ create of DAO +++");
		System.out.println("+++ Employee Created +++");
	}

}
