package com.ameya.postprocessors;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class CustomBeanPostProcessor implements BeanPostProcessor {
	@Override
	public Object postProcessAfterInitialization
	(Object bean, String beanName) throws BeansException {
	System.out.println("+++ Post Process After Initialization :: "+beanName);
		return bean;
	}
	@Override
	public Object postProcessBeforeInitialization
	(Object bean, String beanName) throws BeansException {
	System.out.println("+++ Post Process Before Initialization :: "+beanName);
		return bean;
	}
}
