package com.ameya.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ameya.configs.JdbcConfig;
import com.ameya.daos.StudentDAO;
import com.ameya.models.Student;

public class TestJdbc {

	public static void main(String[] args) {
		ApplicationContext ctx=new 
				AnnotationConfigApplicationContext(JdbcConfig.class);
		StudentDAO studentDao=(StudentDAO)ctx.getBean("studentDao");
		studentDao.create("Ameya", 16, 72, "1992");
		List<Student>students=studentDao.listStudents();
		for(Student student : students) {
			System.out.print("ID : "+student.getId());
			System.out.print(", NAME : "+student.getName());
			System.out.print(", AGE : "+student.getAge());
			System.out.print(", MARKS : "+student.getMarks());
			System.out.println(", YEAR : "+student.getYear());
			System.out.println("------------------------------");
		}
	}

}
