package com.ameya.configs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages= {"com.ameya"})
@EnableTransactionManagement
@PropertySource("classpath:dbProps.properties")
public class JdbcConfig {

	@Autowired
	private Environment env;
	
	@Bean(name="dataSource")
	public DriverManagerDataSource dataSource() {
		System.out.println(env.getProperty("db.password")+
				"\n"+env.getProperty("db.uname")+
				"\n"+env.getProperty("db.url")+
				"\n"+env.getProperty("db.driverClassName"));
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("db.driverClassName"));
		dataSource.setUrl(env.getProperty("db.url"));
		dataSource.setUsername(env.getProperty("db.uname"));
		dataSource.setPassword(env.getProperty("db.password"));
		return dataSource;
	}

	@Bean(name="jdbcTemplate")
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate=new JdbcTemplate();
		jdbcTemplate.setDataSource(dataSource());
		return jdbcTemplate;
	}	
	
	@Bean(name="transactionManager")
	public PlatformTransactionManager transactionManager() {
		DataSourceTransactionManager transactionManager=new
				DataSourceTransactionManager();
		transactionManager.setDataSource(dataSource());
		return transactionManager;
	}
}
