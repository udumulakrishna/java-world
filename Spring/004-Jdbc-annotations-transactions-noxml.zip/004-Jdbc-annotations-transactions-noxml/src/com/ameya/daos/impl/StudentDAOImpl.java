package com.ameya.daos.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ameya.daos.StudentDAO;
import com.ameya.models.Student;
import com.ameya.utils.StudentRowMapper;

@Repository("studentDao")
public class StudentDAOImpl implements StudentDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	private static int id=1;
	@Override
	@Transactional(propagation=Propagation.REQUIRED,isolation=Isolation.DEFAULT)
	public void create(String name, Integer age, Integer marks, String year) {
		final String SQL1="insert into student (id,name,age) values (?,?,?)";
		final String SQL2="insert into marks (sid,marks,year) values(?,?,?)";
		
		jdbcTemplate.update(SQL1,id,name,age);
		System.out.println("+++ Record ADDED To STUDENT TABLE +++");
		jdbcTemplate.update(SQL2,id,marks,year);
		System.out.println("+++ Record ADDED To MARKS TABLE +++");
		id+=1;
	}

	@Override
	public List<Student> listStudents() {
		List<Student>students=null;
		final String SQL="select * from student,marks where student.id=marks.sid";
		students=jdbcTemplate.query(SQL, new StudentRowMapper());
		return students;
	}

}
