package com.ameya.pojo;

public class TimeOfDay {
	private String partOfDay;

	public TimeOfDay() {
	}

	public TimeOfDay(String partOfDay) {
		this.partOfDay = partOfDay;
	}
	public void setPartOfDay(String partOfDay) {
		this.partOfDay = partOfDay;
	}
	public String getPartOfDay() {
		return partOfDay;
	}
}
