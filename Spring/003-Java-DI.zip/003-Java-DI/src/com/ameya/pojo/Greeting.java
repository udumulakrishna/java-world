package com.ameya.pojo;

public class Greeting {
	private String message;
	private TimeOfDay timeOfDay;
	public Greeting() {
		this.message="Hello All Good !...";
	}
	public Greeting(TimeOfDay timeOfDay) {
		this.message="Hello All Good !...";
		this.timeOfDay = timeOfDay;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public TimeOfDay getTimeOfDay() {
		return timeOfDay;
	}
	public void setTimeOfDay(TimeOfDay timeOfDay) {
		this.timeOfDay = timeOfDay;
	}
	@Override
	public String toString() {
		return "Greeting [message=" + message + ", timeOfDay=" + timeOfDay.getPartOfDay() + "]";
	}
	
}
