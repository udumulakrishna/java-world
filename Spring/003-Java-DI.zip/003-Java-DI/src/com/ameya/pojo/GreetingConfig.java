package com.ameya.pojo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@Import(SomeOtherConfig.class)
//@ImportResource("classpath:beans.xml")
public class GreetingConfig {

	@Bean(name="gr1")
	//@Bean(initMethod="init",destroyMethod="destroy")
	//@Scope("prototype")
	public Greeting getGreeting() {
		return new Greeting(getTimeOfDay());
	}
	
	@Bean(name="gr2")
	public Greeting getOtherGreeting() {
		return new Greeting();
	}
	@Bean
	public TimeOfDay getTimeOfDay() {
		return new TimeOfDay("  MORNING !");
	}
}
