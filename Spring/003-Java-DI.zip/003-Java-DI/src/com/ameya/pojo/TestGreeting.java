package com.ameya.pojo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestGreeting {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new 
				AnnotationConfigApplicationContext(GreetingConfig.class);
		//Greeting greeting=(Greeting)context.getBean(Greeting.class);
		Greeting greeting=(Greeting)context.getBean("gr1");
		System.out.println(greeting);
	}

}
