package com.ameya.daos;

import java.util.List;

import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;

import com.ameya.models.Customer;

public interface CustomerDAO extends CassandraRepository<Customer, String> {
	 
	@AllowFiltering
	public List<Customer> findByFirstname(String firstname);
 
	@AllowFiltering
	public List<Customer> findByAgeGreaterThan(int age);
}


/*
public interface CustomerDAO extends CrudRepository<Customer, String> {
	
	@Query(value="SELECT * FROM customer WHERE firstname=?0")
	public List<Customer> findByFirstname(String firstname);

	@Query("SELECT * FROM customer WHERE age > ?0 ALLOW FILTERING")
	public List<Customer> findCustomerHasAgeGreaterThan(int age);
}
*/