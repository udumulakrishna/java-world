package com.ameya;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.ameya.daos.CustomerDAO;
import com.ameya.models.Customer;

@SpringBootApplication
public class Application implements CommandLineRunner{
	
@Autowired
CustomerDAO customerRepository;

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(Application.class, args);
		context.close();
	}

	@Override
	public void run(String... args) throws Exception {
		clearData();
		saveData();
		lookup();
	}
	
	public void clearData(){
		customerRepository.deleteAll();
	}
	
	public void saveData(){
		System.out.println("===================Save Customers to Cassandra===================");
		Customer cust_1 = new Customer(1, "Ameya", "Joshi", 20);
        Customer cust_2 = new Customer(2, "Amol", "Kulkarni", 25);
        Customer cust_3 = new Customer(3, "Ameya", "Wagh", 30);
        Customer cust_4 = new Customer(4, "Avani", "Joshi", 20);
        // save customers to ElasticSearch
        customerRepository.save(cust_1);
        customerRepository.save(cust_2);
        customerRepository.save(cust_3);
        customerRepository.save(cust_4);
	}
	
	public void lookup(){
		System.out.println("===================Lookup Customers from Cassandra by Firstname===================");
		List<Customer> customers = customerRepository.findByFirstname("Ameya");
		customers.forEach(System.out::println);

		System.out.println("===================Lookup Customers from Cassandra by Age===================");
		List<Customer> custsAgeGreaterThan25 = customerRepository.findByAgeGreaterThan(25);
		custsAgeGreaterThan25.forEach(System.out::println);
	}
}
