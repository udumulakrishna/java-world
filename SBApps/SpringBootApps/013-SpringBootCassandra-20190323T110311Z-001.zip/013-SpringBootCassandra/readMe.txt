Create a new spring starter project

add cassandra, web dependency as in pom.xml web will be required only if u are going to code a Rest service else can be omitted

goto cqlsh from cmd
ubuntu1804javaspringboot@ubuntu:~$ cqlsh

create a table customer in keyspace cassandratutorial as below 
cqlsh> use cassandratutorial ;
cqlsh:cassandratutorial> CREATE TABLE customer(
                     ...    id int PRIMARY KEY,
                     ...    firstname text,
                     ...    lastname text,
                     ...    age int
                     ... );

Run the select query
cqlsh:cassandratutorial> select * from customer;
No rows will be shown

Code in the model class Customer
Code in the DAO interface CustomerDAO
Modify the Application class as in demo See the main method demonstrate How to explicitly programmatically stop/shutdown a spring boot app

Run the application as SpringBoot Application 
Observe the o/p

again run the select query
cqlsh:cassandratutorial> select * from customer;

The rows inserted will be shown