-------------------- This is before creating any project in sts ---------------------------------

--- For linux start activemq service
On shell prompt 
traverse to ubuntu1804javaspringboot@ubuntu:~/activemq/apache-activemq-5.15.8-bin/apache-activemq-5.15.8/bin/linux-x86-64
invoke following command
ubuntu1804javaspringboot@ubuntu:~/activemq/apache-activemq-5.15.8-bin/apache-activemq-5.15.8/bin/linux-x86-64 $ ./activemq console
once the service starts 
goto browser and invoke localhost:8161/admin/
enter username/password admin/admin

--- For windows start activemq service
Install the activemq by unzipping the downloaded zip

open comd prompt at E:\practice\spring-boot\apache-activemq-5.11.1-bin\apache-activemq-5.11.1\bin\win64

Run activemq.bat

in browser open localhost:8161/
Click on manage ActiveMQ broker
Click on the queues tab (refresh if necessary)

------------------- Create the project as below -------------------------------


Create an empty Maven project
Populate the required ActiveMQ and spring boot and jackson dependencies along with the others
Code in com.ameya.jms.models.Email.java
Code in the com.ameya.jms.receiver.Receiver.java--->Jms Receiver i.e. JmsListener
Code in com.ameya.jms.JmsApplication.java--->This creates converts and sends the email msg.
Make the appropriate entries in application.properties.

It also acts as SpringBoot application

Code in the TestAndReceive.java with main method

Run the application (invoke TestAndReceive.java ) as spring boot application

On Console the msg will be shown 
Sending an email message.
Received <Email{to=ameya@jms.com, body=Hello Ameya}>

