package com.ameya;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.core.JmsTemplate;

import com.ameya.jms.models.Email;

public class TestSendAndReceive {
	 public static void main(String[] args) {
	        // Launch the application by launching the JmsApplication class explicitly
		 	// this could have been done by having a main method for JmsApplication class
		 	// and running it as normally we do
		 	//this is just to demo how a class could explicitly be run through other class
	        ConfigurableApplicationContext context = 
	        		SpringApplication.run(JmsApplication.class, args);

	        JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);
	        // Send a message with a POJO - the template reuse the message converter
	        System.out.println("Sending an email message.");
	        jmsTemplate.
	        convertAndSend("mailbox-Queue", 
	        		new Email("ameya@jms.com", "Hello Ameya"));
	    }
}
