Create a new Spring starter project 014-SpringBootDockerized
Add web dependency
Edit the pom.xml note the plugins tag and packaging tag
Run the app as maven install by rt click app and run as maven install ---> this will create the jar file
Note the name of the jar
Create the "Dockerfile" in the project the name should be same as mentioned
FROM openjdk:8 --->Get this from docker hub
ADD target/springbootdockerized.jar--->Add this to my docker image springbootdockerized.jar --->
EXPOSE 9001 --->Expose this port for my app
ENTRYPOINT ["java", "-jar", "springbootdockerized.jar"] --->this is the command to execute the app


traverse to the project folder in terminal
ubuntu1804javaspringboot@ubuntu:~$ cd practice/springboot/ws1902/014-SpringBootDockerized/

Build the docker image
ubuntu1804javaspringboot@ubuntu:~/practice/springboot/ws1902/014-SpringBootDockerized$ docker build -f Dockerfile -t springbootdockerized .

Check if image is created 
ubuntu1804javaspringboot@ubuntu:~/practice/springboot/ws1902/014-SpringBootDockerized$ docker images

run the image

ubuntu1804javaspringboot@ubuntu:~/practice/springboot/ws1902/014-SpringBootDockerized$ docker run -p 9001:9001 springbootdockerized

open the other terminal and run : ubuntu1804javaspringboot@ubuntu:~$ curl http://localhost:9001/topics