package com.ameya.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.ameya.models.UserInfo;
import com.ameya.service.UserInfoService;

@RestController
@RequestMapping(value = { "/userinfo" })
public class UserInfoController {

	@Autowired
	private UserInfoService userInfoService;

	@GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserInfo> getUserById(@PathVariable("id") int id) {
		System.out.println("Fetching User with id " + id);
		UserInfo userInfo = userInfoService.findById(id);
		if (userInfo == null) {
			return new ResponseEntity<UserInfo>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<UserInfo>(userInfo, HttpStatus.OK);
	}

	@PostMapping(value = "/create", headers = "Accept=application/json")
	public ResponseEntity<Void> createUser(@RequestBody UserInfo userInfo, UriComponentsBuilder ucBuilder) {
		System.out.println("Creating UserInfo " + userInfo.getName());
		userInfoService.createUserInfo(userInfo);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/userinfo/{id}").buildAndExpand(userInfo.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	@GetMapping(value = "/get", headers = "Accept=application/json")
	public List<UserInfo> getAllUsersInfo() {
		List<UserInfo> allUsersInfo = userInfoService.getAllUsersInfo();
		return allUsersInfo;

	}

	@PutMapping(value = "/update", headers = "Accept=application/json")
	public ResponseEntity<String> updateUserInfo(@RequestBody UserInfo currentUserInfo) {
		UserInfo userInfo = userInfoService.findById(currentUserInfo.getId());
		if (userInfo == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		userInfoService.update(currentUserInfo, currentUserInfo.getId());
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@DeleteMapping(value = "/{id}", headers = "Accept=application/json")
	public ResponseEntity<UserInfo> deleteUserInfo(@PathVariable("id") int id) {
		UserInfo userInfo = userInfoService.findById(id);
		if (userInfo == null) {
			return new ResponseEntity<UserInfo>(HttpStatus.NOT_FOUND);
		}
		userInfoService.deleteUserInfoById(id);
		return new ResponseEntity<UserInfo>(HttpStatus.NO_CONTENT);
	}

	@PatchMapping(value = "/{id}", headers = "Accept=application/json")
	public ResponseEntity<UserInfo> updateUserPartially(@PathVariable("id") int id, @RequestBody UserInfo currentUserInfo) {
		UserInfo userInfo = userInfoService.findById(id);
		if (userInfo == null) {
			return new ResponseEntity<UserInfo>(HttpStatus.NOT_FOUND);
		}
		UserInfo updatedUserInfo = userInfoService.updatePartially(currentUserInfo, id);
		return new ResponseEntity<UserInfo>(updatedUserInfo, HttpStatus.OK);
	}
}
