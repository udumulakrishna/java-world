insert into topic values(101,'JavaSE','Introduction to Core Java 3 days');
insert into topic values(102,'JavaEE','Introduction to JavaEE 3 days');

