package com.ameya.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
	@RequestMapping(path="/welcome",method=RequestMethod.GET)
	public String welcomeMsg() {
		return "<h2>!! ...Welcome To Spring Boot... !!</h2>";
	}
}
