package com.ameya.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.ameya.daos.TopicDAO;
import com.ameya.models.Topic;
import com.ameya.services.TopicService;

@Service
public class TopicServiceImpl implements TopicService {
	@Autowired
	private TopicDAO topicDAO;
	@Override
	public List<Topic> getAllTopics() {
		return topicDAO.getAllTopics();
	}
	@Override
	public void addTopic(Topic topic) {
		topicDAO.addTopic(topic);
	}
	@Override
	public void updateTopic(String id, Topic topic) {
		topicDAO.updateTopic(id, topic);
	}
	@Override
	public Topic getTopic(String id) {
		return topicDAO.getTopic(id);
	}
	@Override
	public void deleteTopic(String id) {
		topicDAO.deleteTopic(id);
	}
}
