package com.ameya.aspects;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspectJ {
	
	@Pointcut("execution(* com.ameya.service.EmployeeService.*(..))")
	public void myPointcut() {}

	@Before(value="myPointcut()")	
	public void beforeAdvice(JoinPoint joinPoint) {
		System.out.println("Before Advice --> Before Method :: "
	+joinPoint.getSignature());
	}
	
	@After(value="myPointcut()")
	public void afterAdvice(JoinPoint joinPoint) {
		System.out.println("After Advice --> After Method :: "
	+joinPoint.getSignature());
	}
	
	@Around(value="myPointcut()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint)throws Throwable{
		Object object=null;
		System.out.println("Around Advice --> Before Method :: "
				+joinPoint.getSignature());
		try {
			object=joinPoint.proceed();
			System.out.println("Around Advice --> After Method :: "
			+joinPoint.getSignature());
		}catch(Throwable t) {
			throw t;
		}
		return object;
	}
}
