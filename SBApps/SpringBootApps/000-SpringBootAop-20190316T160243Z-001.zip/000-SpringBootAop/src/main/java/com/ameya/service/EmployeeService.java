package com.ameya.service;

import org.springframework.stereotype.Service;

import com.ameya.model.Employee;

@Service
public class EmployeeService {
	
	public Employee create(String name,String empId) {
		Employee emp=new Employee();
		emp.setName(name);
		emp.setEmpId(empId);
		System.out.println("+++ employeeService Invoked +++");
		return emp;
	} 
}
