package com.ameya.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ameya.model.Employee;
import com.ameya.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping(value="/add/employee", method=RequestMethod.GET)
	public String addemployee(@RequestParam("name") String name,
			@RequestParam("empId") String empId) {
		employeeService.create(name, empId);
		return "Employee Added";
	}
}
