package com.ameya.model;

public class Employee {
	private String empId;
	private String name;
	public Employee() {}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpId() {
		return empId;
	}
}
